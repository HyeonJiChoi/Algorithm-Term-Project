﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//전체를 통괄하는 프로세스
public class Process : MonoBehaviour {
    static public class Define
    {
        public const bool USED = true;
        public const bool UNUSED = false;
        public const double INFINITE = 99999f;
    }
    public struct ReportInfo //신고 정보
    {
        public int area;
        public double GoldenTime;//매 순서 마다 골든타임은 무조건 줄여주기.
    }
    public struct AreaInfo //장소 정보
    {
        public string name;
        public double x, y;
        public bool state;
    }
    public struct PathInfo //길 정보
    {
        public int start, end;
        public double distance;
        public float rotation;
    }

    public int report_count, area_count, ambulance_count, total_report_count, path_count, remain_ambulcance;
    public AreaInfo[] area;
    public PathInfo[] path;
    public GameObject Button;
    public GameObject[] Ambulance;
    Stack<int> ChangePassArea, ChangePassPath, PassArea, PassPath, Back_PassArea, Back_PassPath,
        PassArea1, PassPath1, PassArea2, PassPath2;
    int CanAmbulance;
    int[] isState;
    Queue<ReportInfo> waitingReport;
	void Start () {
        Button = GameObject.Find("Button");
        report_count = 0;
        total_report_count = 0;
        area_count = 21;
        ambulance_count = 3;
        path_count = 36;
        remain_ambulcance = 3;
        Ambulance = new GameObject[ambulance_count];
        for (int i = 0; i < ambulance_count; i++)
        {
            Ambulance[i] = GameObject.Find("Ambulance_"+(i+1));
        }
        isState = new int[ambulance_count];
        for (int i = 0; i < ambulance_count; i++)
        {
            isState[i] = 0;
        }
        area = new AreaInfo[area_count];
        path = new PathInfo[path_count];
        waitingReport = new Queue<ReportInfo>();
        //정보들 저장하기
        SetArea();
        SetPath();
    }
	
	// Update is called once per frame
	void Update () {
        ProcessAll();
    }
    public void ProcessAll()
    {
        if (report_count > total_report_count)
        { 
            total_report_count++;
            ReportInfo new_report = new ReportInfo();
            new_report.area = Get_area(Button.GetComponent<Button>().Location);
            new_report.GoldenTime = Get_goldentTime(Button.GetComponent<Button>().Disease);
            if (new_report.area != -1)//area에러 체크
            {
                waitingReport.Enqueue(new_report);
            }
            else
            {
                report_count--;
                total_report_count--;
            }
        }
        AmbulanceActive(); 
        if (remain_ambulcance > 0)//남아 있는 구급차가 한개 이상일 때,
        {
            //큐에 한개도 없다면 아무것도 하지않기
            if (waitingReport.Count == 0) { }
            else
            {
                Min_goldenTime();
                report_count--;
                total_report_count--;
                ReportInfo now_report = waitingReport.Dequeue();
                //큐에 한개라도 있다면 앞에서부터 실행 시작
                //목적지까지 다익으로 처리
                double DistanceReportArea = Dijstra(0, now_report.area, 0);
                //만약 골든타임이 다익보다 더 크면 버스를 그냥 보내기
                if (DistanceReportArea <= now_report.GoldenTime)
                {
                    remain_ambulcance--;
                    SetAmbulanceInfo(GetAmbulance(), now_report, PassArea, PassPath);
                }
                else if (now_report.GoldenTime > 0)
                {
                    //안크다면 
                    //지금 활동하고 있는(목적지로 가고잇는) 차(1)가 있는가?
                    //엠불란스의 상태 확인.
                    if (AmbulanceActive())
                    {
                        int OtherAmbulance;
                        if ((OtherAmbulance = OtherDistance_possible(now_report)) > -1)//그외에 것 확인
                        {
                            remain_ambulcance--;
                            SetAmbulanceInfo(GetAmbulance(),Ambulance[OtherAmbulance].GetComponent<Ambulance_c>().report,PassArea,PassPath);
                            SetAmbulanceInfo(OtherAmbulance, now_report,ChangePassArea,ChangePassPath);
                            Ambulance[OtherAmbulance].GetComponent<Ambulance_c>().Change_schedule = true;
                        }
                    }

                }
            }
        }

        ReportInfo tmpReport;
        //모든 신고의 golden타임 줄여주기.
        for(int i=0; i < total_report_count; i++)
        {
            if (waitingReport.Count != 0)
            {
                tmpReport = (ReportInfo)waitingReport.Dequeue();
                tmpReport.GoldenTime -= 0.1;
                waitingReport.Enqueue(tmpReport);
            }
        }
        for (int i = 0; i < ambulance_count; i++)
        {
            if (isState[i] != 0)
                Ambulance[i].GetComponent<Ambulance_c>().report.GoldenTime -= 0.1;
        }

    }
    public void Min_goldenTime()
    {
        ReportInfo[] arr = waitingReport.ToArray();
        double Min;
        int Min_index = 0;
        Min = 300f;
        for(int i=0; i<report_count; i++)
        {
            if (Min > arr[i].GoldenTime)
            {
                Min = arr[i].GoldenTime;
                Min_index = i;
            }
        }
        ReportInfo tmp = arr[Min_index];
        arr[Min_index] = arr[0];
        arr[0] = tmp;

        waitingReport = new Queue<ReportInfo>(arr);

    }
    public bool AmbulanceActive()
    {
        bool Active = false;
        for (int i = 0; i < ambulance_count; i++)
        {
            if (Ambulance[i].GetComponent<Ambulance_c>().state == 1) //상태가 출발중이면 조정 후 true반환
            { isState[i] = 1; Active = true; }
            else if (Ambulance[i].GetComponent<Ambulance_c>().state == 2) //돌아오는 중이면 2로 하고 신경 안슴
            { isState[i] = 2; }
            else if (Ambulance[i].GetComponent<Ambulance_c>().state == 0) //도착함..
                isState[i] = 0;
        }
        return Active;
    }
    public void SetAmbulanceInfo(int number, ReportInfo a_report,Stack<int> new_PassArea, Stack<int> new_PassPath)
    {//싹다 세팅
        Ambulance[number].GetComponent<Ambulance_c>().PassArea = new_PassArea;
        Ambulance[number].GetComponent<Ambulance_c>().PassPath = new_PassPath;
        Ambulance[number].GetComponent<Ambulance_c>().end_Area = a_report.area;
        Ambulance[number].GetComponent<Ambulance_c>().report = a_report;
        Dijstra(a_report.area, 0, 3);
        Ambulance[number].GetComponent<Ambulance_c>().Back_PassArea = Back_PassArea;
        Ambulance[number].GetComponent<Ambulance_c>().Back_PassPath = Back_PassPath;
        Ambulance[number].GetComponent<Ambulance_c>().StartGo = true;

    }
    public int GetAmbulance()
    {
        for (int i = 0; i < ambulance_count; i++)
        {
            if (isState[i] == 0)
            {
                isState[i] = 1;
                return i;
            }
        }
        return -1;
    }
    public double Length(double x1,double x2, double y1, double y2)
    {
        return Math.Sqrt(Math.Pow(x1 - x2, 2) + Math.Pow(y1 - y2, 2)); 
    }
    public double Dijstra( int startArea, int endArea, int state)//다익스트라
    {
        Stack<int> new_PassArea = new Stack<int>();
        Stack<int> new_PassPath = new Stack<int>();
        if (startArea == endArea) return 0;
        double pathTmp; //가장 짧은 거리 찾을 때 쓰는 것
        int pathTmp_index = 0; //가장 짧은 거리 인덱스 저장
        double[] shortest_path = new double[area_count]; //현재 짧은 거리라고 생각 된 값을 넣음.
        int[] passArea_tmp = new int[area_count];
        int[] passPath_tmp = new int[area_count];
        for (int i = 0; i < area_count; i++)
        {
            shortest_path[i] = Define.INFINITE;
        }
        shortest_path[startArea] = 0;
        passArea_tmp[startArea] = -1;
        area[startArea].state = Define.USED;
        for (int index = 0; index < area_count; index++)
        {
            pathTmp = Define.INFINITE;

            //길의 시작 area가 사용한 것만 전에 값과 비교하며 계산한다.
            for (int pathIndex = 0; pathIndex < path_count; pathIndex++)
            {
                if (area[path[pathIndex].start].state == Define.UNUSED) continue;
                if (shortest_path[path[pathIndex].end] > path[pathIndex].distance + shortest_path[path[pathIndex].start])
                {
                    shortest_path[path[pathIndex].end] = path[pathIndex].distance + shortest_path[path[pathIndex].start];
                    passArea_tmp[path[pathIndex].end] = path[pathIndex].start;//지나온 Area을 저장하기 위한 것
                    passPath_tmp[path[pathIndex].end] = pathIndex;//지나온 Path를 저장하기 위한 것
                }
            }
            //수정을 완료한 것중에서 가장 짧은 거리를 구한다.
            for (int areaIndex = 0; areaIndex < area_count; areaIndex++)
            {
                if (area[areaIndex].state == Define.USED) continue;
                if (pathTmp > shortest_path[areaIndex])
                {
                    pathTmp = shortest_path[areaIndex];
                    pathTmp_index = areaIndex;
                }
            }
            //구한다음, area를 사용했다고 표시해준다.
            area[pathTmp_index].state = Define.USED;
        }

        //지나온 area 저장
        int now_area = endArea;
        new_PassArea.Push(now_area);
        while (passArea_tmp[now_area] != -1)
        {
           new_PassArea.Push(passArea_tmp[now_area]);
            now_area = passArea_tmp[now_area];
        }

        //지나온 path 저장
        now_area = endArea;
        while (path[passPath_tmp[now_area]].start != startArea)
        {
            new_PassPath.Push(passPath_tmp[now_area]);
            now_area = path[passPath_tmp[now_area]].start;
        }
        new_PassPath.Push(passPath_tmp[now_area]);

        if (state == 0)
        {
            PassArea = new_PassArea;
            PassPath = new_PassPath;
        }
        if (state == 1)
        {
            PassArea1 = new_PassArea;
            PassPath1 = new_PassPath; 
        }
        if(state == 2)
        {
            PassArea2 = new_PassArea;
            PassPath2 = new_PassPath;
        }
        if(state == 3)
        {
            Back_PassArea = new_PassArea;
            Back_PassPath = new_PassPath;
        }
        return  shortest_path[endArea];

    }
    public int OtherDistance_possible(ReportInfo nowReport)
    {
        for (int i=0; i<ambulance_count; i++) {
            if (isState[i] == 1)
            {
                if (DoubleNode(i))//반대쪽도 길이 있으면,
                {
                    //지금 활동하고 있는 차의 위치에서 
                    //min(출발노드와의 거리 + 출발노드에서 새로생긴 목적지까지의 다익스트라 거리  , 끝노드와의 거리 + 끝노드에서 새로생긴 목적지까지의 다익스트라 거리 )
                    //가 골든타임을 넘는가?
                    if (GetMin(i, nowReport.area) <= nowReport.GoldenTime)
                    {
                        if (Dijstra(0, Ambulance[i].GetComponent<Ambulance_c>().end_Area, 0) < Ambulance[i].GetComponent<Ambulance_c>().report.GoldenTime)
                        {
                            return i;
                        }

                    }
                }
                else //한방향만 된다면,
                {
                    int sub_Area = Ambulance[i].GetComponent<Ambulance_c>().sub_area;
                    double sub_distance = Length(Ambulance[i].transform.position.x, area[sub_Area].x, Ambulance[i].transform.position.y, area[sub_Area].y)
                        + Dijstra(sub_Area, nowReport.area, 2);
                    ChangePassArea = PassArea2; ChangePassPath = PassPath2;
                    if (sub_distance <= nowReport.GoldenTime) //골든타임보다 거리가 더 짧다면 
                    {
                        if (Dijstra(0, Ambulance[i].GetComponent<Ambulance_c>().end_Area, 0) < Ambulance[i].GetComponent<Ambulance_c>().report.GoldenTime)
                        { //그리고 현재 앰불란스의 골든타임을 다른 앰불란스가 해결할 수 있다면, 
                            return i;
                        }
                    }
                }
            }
        }

        return -1;
    }
    public bool DoubleNode(int number)
    {
        for (int i = 0; i < path_count; i++)
        {
            if(path[i].start == Ambulance[number].GetComponent<Ambulance_c>().sub_area && path[i].end == Ambulance[number].GetComponent<Ambulance_c>().pre_area)
                return true;
        }
        return false;
    }
    public double GetMin(int number, int end_Area)
    {
        int pre_Area = Ambulance[number].GetComponent<Ambulance_c>().pre_area, sub_Area = Ambulance[number].GetComponent<Ambulance_c>().sub_area;

        double pre_distance = Length(Ambulance[number].transform.position.x, area[pre_Area].x, Ambulance[number].transform.position.y, area[pre_Area].y) 
            + Dijstra(pre_Area, end_Area, 1);
        double sub_distance = Length(Ambulance[number].transform.position.x, area[sub_Area].x, Ambulance[number].transform.position.y, area[sub_Area].y) 
            + Dijstra(sub_Area, end_Area, 2);
        double min_distance = Math.Min(pre_distance, sub_distance);
        if (pre_distance == min_distance) { ChangePassArea = PassArea1; ChangePassPath = PassPath1; }
        else { ChangePassArea = PassArea2; ChangePassPath = PassPath2; }
        return min_distance;
    }
    public int Get_area(string location) //모든 area정보에서 이름에 알맞는 index값 찾기
    {
        for(int i=0; i<area_count; i++)
        {
            if (string.Equals(location, area[i].name)) { return i; };
        }
        return -1;
    }
    public double Get_goldentTime(string diseases)  //골든타임 찾기
    {
        double Goldentime = 100f;
        if (string.Equals(diseases, "SCRATCH"))//작은 상처
            Goldentime =  200f;
        if (string.Equals(diseases, "COLD")) //감기
            Goldentime = 200f;
        if (string.Equals(diseases, "BROKEN"))//뼈 부러짐
            Goldentime = 100f;
        if (string.Equals(diseases, "BLEEDING"))//출혈
            Goldentime = 80f;
        if (string.Equals(diseases, "FLU"))//독감
            Goldentime = 180f;
        if (string.Equals(diseases, "FAINT"))//기절
            Goldentime = 70f;
        if (string.Equals(diseases, "HEART ATTACK"))//심장마디
            Goldentime = 30f;
        if (string.Equals(diseases, "HEATSTROKE"))//일사병
            Goldentime = 40f;
        if (string.Equals(diseases, "DEHYDRATION"))//탈수
            Goldentime = 50f;
        if (string.Equals(diseases, "HYPOTENSION"))//저혈압
            Goldentime = 60f;
        if (string.Equals(diseases, "DIABETES"))//당뇨
            Goldentime = 60f;
        if (string.Equals(diseases, "EXHAUSTED"))//탈진
            Goldentime = 80f;
        if (string.Equals(diseases, "HEMORRHAGE"))//뇌출혈
            Goldentime = 30f;
        if (string.Equals(diseases, "CONCUSSION"))//뇌진탕
            Goldentime = 30f;
        if (string.Equals(diseases, "HIGHBLOODPRESSURE"))//고혈압
            Goldentime = 60f;
        if (string.Equals(diseases, "FOODPOISONING"))//식중독
            Goldentime = 100f;
        if (string.Equals(diseases, "BURN"))//화상
            Goldentime = 100f;
        if (string.Equals(diseases, "GOUT"))//통풍
            Goldentime = 100f;
        if (string.Equals(diseases, "TENTANUS"))//파상풍
            Goldentime = 140f;
        if (string.Equals(diseases, "CAECUM"))//맹장
            Goldentime = 50f;
        if (string.Equals(diseases, "MERS"))//메르스
            Goldentime = 150f;
        if (string.Equals(diseases, "TUBERCULOSIS"))//결핵
            Goldentime = 100f;
        if (string.Equals(diseases, "FINGERBROKEN"))//손 부상
            Goldentime = 200f;
        if (string.Equals(diseases, "ANKLEBROKEN"))//발목 염좌
            Goldentime = 200f;
        if (string.Equals(diseases, "SPRAIN"))//삠
            Goldentime = 200f;
        if (string.Equals(diseases, "STOMACHE"))//복통
            Goldentime = 150f;
        if (string.Equals(diseases, "ENTERITIS"))//장염
            Goldentime = 150f;


        int Degree = Button.GetComponent<Button>().Degree;

        if (Degree == 0) Goldentime += 50;
        else if (Degree == 1) Goldentime += 25;


        return Goldentime;
    }
    public void SetArea()
    {
        InputAreaInfo("Hospital", 0);
        InputAreaInfo("A", 1);
        InputAreaInfo("B", 2);
        InputAreaInfo("C", 3);
        InputAreaInfo("D", 4);
        InputAreaInfo("E", 5);
        InputAreaInfo("F", 6);
        InputAreaInfo("H", 7);
        InputAreaInfo("I", 8);
        InputAreaInfo("J", 9);
        InputAreaInfo("K", 10);
        InputAreaInfo("L", 11);
        InputAreaInfo("N", 12);
        InputAreaInfo("M", 13);
        InputAreaInfo("P", 14);
        InputAreaInfo("Q", 15);
        InputAreaInfo("R", 16);
        InputAreaInfo("S", 17);
        InputAreaInfo("T", 18);
        InputAreaInfo("U", 19);

        //모든부분 저장하기

    }
    public void InputAreaInfo(string new_name,int i) //area에 정보를 넣음.
    {
        GameObject area_object = GameObject.Find(new_name);
        area[i].name = string.Copy(new_name);
        area[i].x = area_object.transform.position.x;
        area[i].y = area_object.transform.position.y;
        area[i].state = Define.UNUSED;
    }
    public void SetPath()
    {
        int count = 0;
        InputPathInfo(0, 12, count);//0
        count++;
        InputPathInfo(0, 13, count);//1
        count++;
        InputPathInfo(0, 15, count);//2
        count++;
        InputPathInfo(1, 4, count);//3
        count++;
        InputPathInfo(1, 16, count);//4
        count++;
        InputPathInfo(2, 3, count);//5
        count++;
        InputPathInfo(3, 2, count);//6
        count++;
        InputPathInfo(3, 6, count);//7
        count++;
        InputPathInfo(4, 5, count);//8
        count++;
        InputPathInfo(4, 12, count);//9
        count++;
        InputPathInfo(5, 4, count);//10
        count++;
        InputPathInfo(5, 6, count);//11
        count++;
        InputPathInfo(5, 8, count);//12
        count++;
        InputPathInfo(6, 3, count);//13
        count++;
        InputPathInfo(6, 5, count);//14
        count++;
        InputPathInfo(7, 8, count);//15
        count++;
        InputPathInfo(8, 5, count);//16
        count++;
        InputPathInfo(8, 13, count);//17
        count++;
        InputPathInfo(9, 7, count);//18
        count++;
        InputPathInfo(10, 9, count);//19
        count++;
        InputPathInfo(10, 19, count);//20
        count++;
        InputPathInfo(11, 10, count);//21
        count++;
        InputPathInfo(12, 1, count);//22
        count++;
        InputPathInfo(12, 0, count);//23
        count++;
        InputPathInfo(13, 11, count);//24
        count++;
        InputPathInfo(13, 0, count);//25
        count++;
        InputPathInfo(14, 13, count);//26
        count++;
        InputPathInfo(15, 14, count);//28
        count++;
        InputPathInfo(15, 16, count);//29
        count++;
        InputPathInfo(16, 1, count);//30
        count++;
        InputPathInfo(16, 15, count);//31
        count++;
        InputPathInfo(16, 17, count);//32
        count++;
        InputPathInfo(17, 18, count);//33
        count++;
        InputPathInfo(18, 19, count);//34
        count++;
        InputPathInfo(19, 15, count);//35
        count++;
    }
    public void InputPathInfo(int start, int end, int count)
    {
        GameObject NewPath = GameObject.Find(area[start].name + "to" + area[end].name);
        path[count].start = start;
        path[count].end = end;
        path[count].distance = Length(area[start].x, area[end].x, area[start].y, area[end].y);
        path[count].rotation = NewPath.transform.localEulerAngles.z;
    }
}
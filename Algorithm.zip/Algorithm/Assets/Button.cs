﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//버튼 인식
public class Button : MonoBehaviour {
    public InputField location_input;
    public InputField disease_input;
    public GameObject process;
    public String Location, Disease;
    public Toggle toggleLight, toggleFatal, toggleSerious;
    public int Degree;
    void Start()
    {
        process = GameObject.Find("Process");
    }
    public void OnClicksStartButton()
    {
        if (toggleLight.isOn) Degree = 0;
        else if (toggleSerious.isOn) Degree = 1;
        else if (toggleFatal.isOn) Degree = 2;
        Location = location_input.text.ToUpper();
        Disease = disease_input.text.ToUpper();
        process.GetComponent<Process>().report_count++;
        toggleLight.isOn = false;
        toggleSerious.isOn = false;
        toggleFatal.isOn = false;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//프로세스의 명령에 따라 각 엠블란스를 움직여주는 클래스
public class Ambulance_c : MonoBehaviour {
    public Stack<int> PassArea;
    public Stack<int> PassPath;
    public Stack<int> Back_PassArea;
    public Stack<int> Back_PassPath;
    public Stack<float> BackRotate;
    public Process.ReportInfo report;
    GameObject Process;
    public int pre_area, sub_area, end_Area, new_nextArea, now_path;
    public int state; //0은 아무것도 안함, 1은 찾아가는중 , 2는 돌아가는길
    public bool Change_schedule, StartGo;//스케줄을 바꿔야하는 상황이면 바꿔주기,가야하는 상황이면 가주기
                         // Use this for initialization
    void Start() {
        state = 0;
        Change_schedule = false;
        StartGo = false;
        Process = GameObject.Find("Process");
    }

    // Update is called once per frame
    void Update() {
        //매번마다 옮겨주기..
        if(StartGo == true)
        {

            state = 1;
            if (Change_schedule == true) //만약 스케줄이 바꼇으면,
            {
                int new_sb_area = PassArea.Pop();
                Change_schedule = false;
                if (sub_area != new_sb_area) //다음에 가야하는 길이 지금 길과 다르면,
                {
                    this.transform.Rotate(0, 0, 180); //180도 회전해주기
                    pre_area = sub_area;
                }
                sub_area = new_sb_area;

            }
            else
            {
                pre_area = (int)PassArea.Pop();
                sub_area = (int)PassArea.Pop();
                now_path = (int)PassPath.Pop();
                this.transform.localRotation = Quaternion.Euler(0, 0, Process.GetComponent<Process>().path[now_path].rotation);
            }
            StartGo = false;
        }
        if (state != 0)
        {
            this.transform.Translate(0, 0.1f, 0);
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (state == 1 && StartGo == false && other.gameObject.tag =="Area") 
        {
            if (string.Equals(other.gameObject.name, Process.GetComponent<Process>().area[end_Area].name)) //붙딪힌 이름이 도착지점과 같으면 도착.
            {
                state = 2;
                pre_area = (int)Back_PassArea.Pop();
                sub_area = (int)Back_PassArea.Pop();
                now_path = (int)Back_PassPath.Pop();
                this.transform.localRotation = Quaternion.Euler(0, 0, Process.GetComponent<Process>().path[now_path].rotation);

            }
            else if(!string.Equals(other.gameObject.name, Process.GetComponent<Process>().area[pre_area].name))
            {
                now_path = (int)PassPath.Pop();
                this.transform.localRotation = Quaternion.Euler(0, 0, Process.GetComponent<Process>().path[now_path].rotation);
                pre_area = sub_area;
                sub_area = (int)PassArea.Pop();
            }
        }
        else if (state == 2) { //돌아갈때도 똑같이 다익스트라로 구현해줌.
            if (other.gameObject.tag == "Hospital")
            {
                state = 0;
                this.transform.localRotation = Quaternion.Euler(0, 0, 0);
                Process.GetComponent<Process>().remain_ambulcance++;
            }
            else if (other.gameObject.tag == "Area" && !string.Equals(other.gameObject.name, Process.GetComponent<Process>().area[pre_area].name))
            {
                now_path = (int)Back_PassPath.Pop();
                this.transform.localRotation = Quaternion.Euler(0, 0, Process.GetComponent<Process>().path[now_path].rotation);
                pre_area = sub_area;
                sub_area = (int)Back_PassArea.Pop();
            }
        }
    }
}
